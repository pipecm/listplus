package cl.listplus.api.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListplusApiUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
